package f00f.net.irc.martyr;

/**
 * Should the state and state observer be one?
 */
public class StateObserver extends ForwardObservable
{
}
