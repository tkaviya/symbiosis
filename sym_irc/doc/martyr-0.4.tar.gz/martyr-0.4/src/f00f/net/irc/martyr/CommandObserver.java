package f00f.net.irc.martyr;

public class CommandObserver extends StateObserver
{
}
