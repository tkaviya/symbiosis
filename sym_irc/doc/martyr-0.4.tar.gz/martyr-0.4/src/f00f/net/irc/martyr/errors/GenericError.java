package f00f.net.irc.martyr.errors;

import f00f.net.irc.martyr.commands.AbstractInCommand;

/**
 * Defines what an error is.  All errors are commands.
 */
public abstract class GenericError extends AbstractInCommand
{

}



